# Mody

## Wyrzuca mnie z serwera i mówi coś o jakichś kluczach.
Masz złe mody. Załaduj odpowiednią listę modów.

## Wyrzuca mnie z serwera przez jakąś weryfikację *.pbo.
Masz złe mody. Załaduj odpowiednią listę modów.

## Pobiera mi od nowa wszystkie mody, co robić?
[Link do poradnika](https://steamcommunity.com/app/107410/discussions/1/135510194254064583/)

## Pobieranie modów nie działa, błąd "Brak pobranych plików"
Należy usunąć wszystko z folderów `temp` oraz `downloads` w katalogu workshop na tym samym dysku co Arma. Przykładowa lokalizacja katalogu workshop `C:\Program Files (x86)\Steam\steamapps\workshop`.
