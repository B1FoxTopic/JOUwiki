# Arma

## Wyskakuje mi jakieś no entry.
Kliknij ok, to normalne. Dopóki nie wyrzuca Cię z serwera lub gra Ci nie crashuje to wszystko jest ok.

## Wybrałem slot, dałem OK i wiszę na pobieraniu danych.
Usuń plik `__cur_mp.pbo` z folderu `%localappdata%\Arma 3\MPMissionsCache`

## Po aktualizacji Steam pokazuje mi że gra nie jest zainstalowana, mimo że znajduje się na dysku
Zweryfikuj czy ARMA jest rzeczywiście zainstalowana w katalogu `X:\SteamLibrary\steamapps\common` (X - litera dysku z grami Steam). Jeżeli tak to:
- Przejdź w aplikacji `Steam->Ustawienia->Pobieranie` i sprawdź, czy katalog na dysku jest poprawnie zmapowany. Możesz dla pewności naprawić folder biblioteki (`PPM->Napraw folder biblioteki`).
- Zgodnie z zaleceniami Steam uruchom ponownie instalację - powinien on samodzielnie znaleźć zainstalowaną kopię gry na dysku i po kilku minutach ją naprawić.
