# ACRE

## Wszedłem na kanał "Gramy" i nikt mi nie odpowiada.
Osoby przebywające w grze słyszą tylko innych, którzy też są w grze.
Wchodzenie na ten kanał nie ma sensu, bo i tak nikt Cię nie usłyszy.
Wiadomości oraz pingów również nie słychać podczas gry.

## Wszystkich wrzuciło na kanał "Gramy", a mnie nie.
Upewnij się, że masz włączony plugin w TS.
Jeśli masz to spróbuj go zrestartować, czasami się wiesza.

## Krótkie radio mi nie działa.
Upewnij się, że przyczepiłeś uchwyt z powrotem po zmianie bloku.

## ACRE nie chce się połączyć z TSem
Upewnij się, że masz włączony plugin w TS.
Jeżeli włączasz TS jako administrator to nie rób tego.

## ACRE w TS nie chce się samo zaktualizować
Pliki pluginów znajdują się w folderze `<Steam>\steamapps\common\Arma 3\!Workshop\@ACRE2\plugin`.
Należy je przekopiować do `%appdata%\TS3Client\plugins`.
