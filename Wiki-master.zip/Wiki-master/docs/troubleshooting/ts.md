# TeamSpeak

## Nie mogę wyciszyć mikrofonu

Niestety plugin ACRE kontroluje wyciszenie mikrofonu i zawsze będzie go odciszał.
Rozwiązaniem jest przełączanie statusu "oddalony".
Dzięki niemu nie można mówić, ale wszystko słychać.
Tak samo jak przy normalnym wyciszeniu mikrofonu.

## Dostaję błąd spam protection

Serwer TeamSpeak ma włączone zabezpieczenie antyspamowe. Administrator powinien ustawić liczbę punktów wymaganą do blokady na jakąś dużą wartość (na naszym serwerze jest ustawione na 100000).
