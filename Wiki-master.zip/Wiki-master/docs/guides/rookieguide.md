# Poradnik dla rekrutów

## Wstęp

Poradnik został opracowany z myślą o graczach dopiero rozpoczynających członkostwo w naszej grupie - jego zamiarem jest poprowadzenie was przez rękę przez wszystkie meandry konfigurowania Army i radzenia sobie z wypracowanymi wewnątrz grupy systemami, do których należą między innymi zasady zapisywania się na misję. Poszczególne kroki są dokładnie opisane, te bardziej wymagające popieramy zrzutami ekranów, znajdziecie w nim również podstawowe FAQ dotyczące zagadnień ogólnych. W razie jakichkolwiek problemów ze zrozumieniem treści poradnika kontaktujcie się ze swoimi opiekunami Rekruterami, lub uderzajcie do jego twórcy na Discordzie - @Nakimeteles.

[Przejdź do poradnika dla rekrutów](https://docs.google.com/document/d/1nOPqnTeu9Flph8oBtN2FFMQ5dUvwFet_Y80uH1ckp1s/edit?usp=sharing)
