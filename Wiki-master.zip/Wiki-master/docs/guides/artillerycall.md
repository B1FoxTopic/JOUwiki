# Wzywanie artylerii

## Wstęp

Poradnik opracowany z myślą o graczach, którzy jako BPP (oddziały piechoty) mają aspiracje większe, niż strzelanie do krzaków i wywalania się na pierwszym kontakcie. Zajmuje się on zagadnieniem efektywnej współpracy piechurów oraz jednostki wsparcia - artylerii. Twórcą poradnika jest @Jabar.

[Być jak KWK Wujek - wzywanie artylerii na pozycje wroga](https://drive.google.com/file/d/17DtQ8Z-7kXtwKS9dSXE29iuRrXvg9yse/view)
