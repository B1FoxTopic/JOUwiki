# ACRE - Troubleshooting

## I joined the designated channel for ACRE mod, but no one's answersing me.

Players already in game can hear only other players in game. There's no point in joining the channel, because nobody's gonna hear you. 
Chat messages and pokes are also muted when playing Arma with ACRE.

## Everybody but me was moved to ACRE channel, why?

Make sure your ACRE plugin is enabled in TeamSpeak settings.
If it is, try restarting it. It might have crashed or experienced a freeze.

## Short-range radio doesn't work for me.

Make sure you attached the handle back to the radio after switching channel block.

## ACRE doesn't connect to TeamSpeak.

Make sure your ACRE plugin is enabled in TeamSpeak settings.
If you are running TS as an administrator - don't.

## ACRE TS plugin doesn't update on its own.

Plugin files can be found in `<Steam>\steamapps\common\Arma3\!Workshop\@ACRE2\plugin`.
Copy them to `%appdata%\TS3Client\plugins`.
