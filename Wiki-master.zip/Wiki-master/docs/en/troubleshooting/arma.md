# Arma

## I got "something something no entry" pop-up.

Click okay, that's normal. As long as you don't get kicked out of the server or the game doesn't crash, you are all good.

## I chose slot in the lobby, clicked OK, and now I am stuck on downloading data.

Delete `__cur_mp.pbo` file from `%localappdata%\Arma 3\MPMissionsCache` directory.
