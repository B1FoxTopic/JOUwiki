# TeamSpeak

## I can't mute my microphone

ACRE plugin controls microphone muting and its default settings always unmute you automatically. Workaround is simple - just set "away" status. It allows you to stay muted and still be able to hear everybody else. Works just the same as microphone muting.

## I keep getting "Action currently not possible due to spam protection"

TeamSpeak server has anti-flood enabled. Server administrator should set point limits to some big value (it is set to 100000 on our server).
